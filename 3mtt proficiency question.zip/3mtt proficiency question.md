﻿These questions cover a broad range of technical topics suitable for both entry-level and intermediate-level proficiency.

\### Entry-level:

1\. What does HTML stand for?

`   `- A) Hyper Transfer Markup Language

`   `- B) Hypertext Markup Language

`   `- C) Hyper Text Makeup Language

`   `- D) Hyper Text Markup Language (Correct)

2\. Which of the following is used to style web pages?

`   `- A) HTML

`   `- B) CSS (Correct)

`   `- C) JavaScript

`   `- D) SQL

3\. What is the purpose of JavaScript in web development?

`   `- A) To style web pages

`   `- B) To create and control dynamic website content (Correct)

`   `- C) To manage databases

`   `- D) To define webpage structure

4\. What does CSS stand for?

`   `- A) Cascading Style System

`   `- B) Creative Style Sheet

`   `- C) Computer Style Sheet

`   `- D) Cascading Style Sheets (Correct)

5\. Which of the following is NOT a version control system?

`   `- A) Git

`   `- B) NPM

`   `- C) SVN

`   `- D) Mercurial (Correct)

6\. What does NPM stand for?

`   `- A) Node Package Manager (Correct)

`   `- B) New Programming Method

`   `- C) Node Project Manager

`   `- D) Node Package Module

7\. What is the purpose of the `git clone` command?

`   `- A) To create a new Git repository

`   `- B) To initialize a Git repository

`   `- C) To copy a repository from a remote source (Correct)

`   `- D) To remove a repository

8\. Which CSS property is used to change the background color of an element?

`   `- A) color

`   `- B) background-color (Correct)

`   `- C) font-family

`   `- D) border

9\. What is the purpose of the `href` attribute in HTML?

`   `- A) It defines the heading of a webpage

`   `- B) It specifies the font color

`   `- C) It defines the link destination (Correct)

`   `- D) It sets the background image

10\. Which tag is used to create an unordered list in HTML?

`   `- A) <ol>

`   `- B) <li>

`   `- C) <ul> (Correct)

`   `- D) <list>

11\. What is the purpose of CSS Grid?

`    `- A) To manipulate database records

`    `- B) To create flexible layouts (Correct)

`    `- C) To manage JavaScript functions

`    `- D) To store media files

12\. What is the purpose of JavaScript variables?

`    `- A) To store and manipulate data (Correct)

`    `- B) To create static web pages

`    `- C) To define webpage structure

`    `- D) To handle server-side logic

13\. Which of the following is used to make a website responsive?

`    `- A) CSS Grid

`    `- B) JavaScript

`    `- C) Media queries (Correct)

`    `- D) NPM

14\. What is the role of the `git push` command?

`    `- A) To fetch changes from a remote repository

`    `- B) To upload local repository changes to a remote repository (Correct)

`    `- C) To discard local changes

`    `- D) To create a new branch

15\. Which CSS property is used to set the font size?

`    `- A) font-style

`    `- B) font-size (Correct)

`    `- C) font-weight

`    `- D) font-family

16\. What does the `npm install` command do?

`    `- A) It initializes a new npm project

`    `- B) It installs dependencies defined in package.json (Correct)

`    `- C) It uninstalls npm packages

`    `- D) It updates all npm packages to their latest versions

17\. Which HTML tag is used to define a hyperlink?

`    `- A) <url>

`    `- B) <link>

`    `- C) <a> (Correct)

`    `- D) <hyperlink>

18\. What is the purpose of the `git commit` command?

`    `- A) To create a new branch

`    `- B) To merge branches

`    `- C) To record changes to the repository (Correct)

`    `- D) To discard changes in the working directory

19\. What is the purpose of the `npm start` command?

`    `- A) To install npm packages

`    `- B) To start a development server (Correct)

`    `- C) To deploy a website

`    `- D) To run unit tests

20\. Which CSS property is used to add spacing between elements?

`    `- A) padding (Correct)

`    `- B) margin

`    `- C) border

`    `- D) spacing

21\. What is the purpose of the `git pull` command?

`    `- A) To push changes to a remote repository

`    `- B) To merge changes from a remote repository into the local repository (Correct)

`    `- C) To delete a branch

`    `- D) To create a new branch

22\. What is the purpose of the `npm init` command?

`    `- A) To install npm packages

`    `- B) To initialize a new npm project (Correct)

`    `- C) To start a development server

`    `- D) To update npm packages

23\. Which HTML tag is used to define a table row?

`    `- A) <tr> (Correct)

`    `- B) <td>

`    `- C) <th>

`    `- D) <table-row>

24\. What is the purpose of the `git branch` command?

`    `- A) To create a new branch (Correct)

`    `- B) To delete a branch

`    `- C) To list all branches

`    `- D) To merge branches

25\. What does CSS specificity refer to?

`    `- A) The order of CSS rules in a stylesheet

`    `- B) The importance of CSS properties

`    `- C) The level of precedence of CSS rules (Correct)

`    `- D) The size of CSS files

26\. What is the purpose of the `npm run build` command?

`    `- A) To start a development server

`    `- B) To build a production-ready version of the application (Correct)

`    `- C) To install npm packages

`    `- D) To deploy a website

27\. Which CSS property is used to specify the font family?

`    `- A) font-style

`    `- B) font-family (Correct)

`    `- C) font-weight

`    `- D) font-size

28\. What is the purpose of the `git merge` command?

`    `- A) To create a new branch

`    `- B) To delete a branch

`    `- C) To combine changes from one branch into another (Correct)

`    `- D) To push changes to a remote repository

29\. Which HTML tag is used to create a hyperlink?

`    `- A) <url>

`    `- B) <link>

`    `- C) <a> (Correct)

`    `- D) <hyperlink>

30\. What is the purpose of the `npm install --save` command?

`    `- A) To install npm packages globally

`    `- B) To install and save dependencies to package.json (Correct)

`    `- C) To uninstall npm packages

`    `- D) To update npm packages

31\. Which CSS property is used to

` `set the text color?

`    `- A) color (Correct)

`    `- B) background-color

`    `- C) text-color

`    `- D) font-color

32\. What does the `git log` command display?

`    `- A) A list of remote repositories

`    `- B) A list of commits in the repository (Correct)

`    `- C) A list of branches

`    `- D) A list of untracked files

33\. What is the purpose of the `npm uninstall` command?

`    `- A) To install npm packages

`    `- B) To remove npm packages (Correct)

`    `- C) To update npm packages

`    `- D) To start a development server

34\. Which CSS property is used to set the width of an element?

`    `- A) height

`    `- B) width (Correct)

`    `- C) size

`    `- D) length

35\. What is the purpose of the `git checkout` command?

`    `- A) To create a new branch

`    `- B) To switch between branches (Correct)

`    `- C) To delete a branch

`    `- D) To merge branches

36\. What does the `npm outdated` command display?

`    `- A) A list of outdated npm packages

`    `- B) A list of installed npm packages

`    `- C) A list of available npm packages

`    `- D) A list of current npm package versions (Correct)

37\. Which HTML tag is used to define the main content of a webpage?

`    `- A) <content>

`    `- B) <body>

`    `- C) <main> (Correct)

`    `- D) <section>

38\. What is the purpose of the `git status` command?

`    `- A) To list all commits in the repository

`    `- B) To display the current state of the working directory and staging area (Correct)

`    `- C) To delete untracked files

`    `- D) To switch between branches

39\. Which CSS property is used to create space between the element's content and its border?

`    `- A) margin (Correct)

`    `- B) padding

`    `- C) border-spacing

`    `- D) spacing

40\. What is the purpose of the `git reset` command?

`    `- A) To create a new commit

`    `- B) To undo changes in the working directory (Correct)

`    `- C) To switch between branches

`    `- D) To merge branches

41\. What does the `npm publish` command do?

`    `- A) It installs npm packages

`    `- B) It updates npm packages

`    `- C) It publishes a package to the npm registry (Correct)

`    `- D) It removes npm packages

42\. Which HTML tag is used to define a list item?

`    `- A) <list>

`    `- B) <li> (Correct)

`    `- C) <item>

`    `- D) <ul>

43\. What is the purpose of the `git remote` command?

`    `- A) To list all remote repositories

`    `- B) To create a new remote repository

`    `- C) To manage remote repositories (Correct)

`    `- D) To switch between remote repositories

44\. Which CSS property is used to specify the thickness of an element's border?

`    `- A) border-width (Correct)

`    `- B) border-size

`    `- C) border-thickness

`    `- D) border

45\. What is the purpose of the `npm search` command?

`    `- A) To search for npm packages

`    `- B) To install npm packages

`    `- C) To update npm packages

`    `- D) To publish npm packages

46\. Which HTML tag is used to define a form?

`    `- A) <input>

`    `- B) <form> (Correct)

`    `- C) <submit>

`    `- D) <data>

47\. What is the purpose of the `git stash` command?

`    `- A) To discard changes in the working directory

`    `- B) To save changes temporarily and revert to the last commit (Correct)

`    `- C) To create a new branch

`    `- D) To switch between branches

48\. Which CSS property is used to specify the font weight?

`    `- A) font-style

`    `- B) font-weight (Correct)

`    `- C) font-family

`    `- D) font-size

49\. What is the purpose of the `npm audit` command?

`    `- A) To update npm packages

`    `- B) To analyze npm packages for vulnerabilities (Correct)

`    `- C) To install npm packages

`    `- D) To remove npm packages

50\. Which HTML tag is used to define a hyperlink?

`    `- A) <url>

`    `- B) <a> (Correct)

`    `- C) <link>

`    `- D) <href>


\### Intermediate-level:

1\. What is the purpose of CSS media queries?

`    `- A) To handle media files in CSS

`    `- B) To manipulate the DOM based on media conditions

`    `- C) To define rules for specific media types or device characteristics (Correct)

`    `- D) To create animations in CSS

2\. Which JavaScript keyword is used to declare a constant variable?

`    `- A) let

`    `- B) var

`    `- C) const (Correct)

`    `- D) def

3\. What does SQL stand for in the context of database management?

`    `- A) Structured Question Language

`    `- B) Static Query Language

`    `- C) Structured Query Language (Correct)

`    `- D) Systematic Query Logic

4\. What is the primary purpose of the Fetch API in JavaScript?

`    `- A) To fetch data from a server (Correct)

`    `- B) To manipulate the DOM

`    `- C) To create animations

`    `- D) To handle form submissions

5\. Which HTTP method is typically used for updating existing data on a server?

`    `- A) GET

`    `- B) PUT

`    `- C) POST

`    `- D) PATCH (Correct)

6\. What is the purpose of CSS specificity?

`    `- A) To specify the order of CSS rules in a stylesheet

`    `- B) To define the importance of CSS properties

`    `- C) To determine the level of precedence of CSS rules (Correct)

`    `- D) To optimize the size of CSS files

7\. Which JavaScript data type is used to represent a collection of elements?

`    `- A) Object

`    `- B) Array (Correct)

`    `- C) String

`    `- D) Boolean

8\. What is the purpose of the `git rebase` command?

`    `- A) To merge changes from one branch into another

`    `- B) To rewrite commit history (Correct)

`    `- C) To switch between branches

`    `- D) To delete a branch

9\. What does the term "asynchronous" mean in JavaScript?

`    `- A) Executing code in a sequential order

`    `- B) Executing code concurrently with other operations (Correct)

`    `- C) Executing code in a single-threaded environment

`    `- D) Executing code based on user interactions

10\. Which JavaScript method is used to iterate over the elements of an array?

`    `- A) forEach (Correct)

`    `- B) map

`    `- C) filter

`    `- D) reduce

11\. What is the purpose of the React component

` `lifecycle methods?

`    `- A) To handle asynchronous operations

`    `- B) To manage component initialization, updates, and destruction (Correct)

`    `- C) To define component styles

`    `- D) To create reusable components

12\. Which CSS unit is relative to the viewport width?

`    `- A) px

`    `- B) vw (Correct)

`    `- C) em

`    `- D) rem

13\. What is the purpose of the `useState` hook in React?

`    `- A) To manage component state (Correct)

`    `- B) To perform side effects in function components

`    `- C) To fetch data from a server

`    `- D) To create reusable components

14\. Which JavaScript method is used to remove elements from an array based on a condition?

`    `- A) splice

`    `- B) filter (Correct)

`    `- C) reduce

`    `- D) find

15\. What is the purpose of the `useEffect` hook in React?

`    `- A) To manage component state

`    `- B) To perform side effects in function components (Correct)

`    `- C) To handle component updates

`    `- D) To create reusable components

16\. What is the purpose of the `git cherry-pick` command?

`    `- A) To merge changes from one branch into another

`    `- B) To apply specific commits from one branch to another (Correct)

`    `- C) To delete a branch

`    `- D) To switch between branches

17\. Which CSS property is used to specify the alignment of text within an element?

`    `- A) text-align (Correct)

`    `- B) text-decoration

`    `- C) text-transform

`    `- D) line-height

18\. What is the purpose of the `useState` hook in React?

`    `- A) To manage component state (Correct)

`    `- B) To perform side effects in function components

`    `- C) To fetch data from a server

`    `- D) To create reusable components

19\. Which JavaScript method is used to remove elements from an array based on a condition?

`    `- A) splice

`    `- B) filter (Correct)

`    `- C) reduce

`    `- D) find

20\. What is the purpose of the `useEffect` hook in React?

`    `- A) To manage component state

`    `- B) To perform side effects in function components (Correct)

`    `- C) To handle component updates

`    `- D) To create reusable components

21\. What is the purpose of the `git cherry-pick` command?

`    `- A) To merge changes from one branch into another

`    `- B) To apply specific commits from one branch to another (Correct)

`    `- C) To delete a branch

`    `- D) To switch between branches

22\. Which CSS property is used to specify the alignment of text within an element?

`    `- A) text-align (Correct)

`    `- B) text-decoration

`    `- C) text-transform

`    `- D) line-height

23\. What is the purpose of the `git stash` command?

`    `- A) To discard changes in the working directory

`    `- B) To save changes temporarily and revert to the last commit (Correct)

`    `- C) To create a new branch

`    `- D) To switch between branches

24\. Which CSS property is used to specify the font weight?

`    `- A) font-style

`    `- B) font-weight (Correct)

`    `- C) font-family

`    `- D) font-size

25\. What is the purpose of the `npm audit` command?

`    `- A) To update npm packages

`    `- B) To analyze npm packages for vulnerabilities (Correct)

`    `- C) To install npm packages

`    `- D) To remove npm packages

26\. Which HTML tag is used to define a hyperlink?

`    `- A) <url>

`    `- B) <a> (Correct)

`    `- C) <link>

`    `- D) <href>

27\. What is the purpose of the `git revert` command?

`    `- A) To create a new branch

`    `- B) To undo specific commits by creating new ones that revert changes (Correct)

`    `- C) To switch between branches

`    `- D) To merge branches

28\. Which CSS property is used to specify the background color of an element?

`    `- A) color

`    `- B) background-color (Correct)

`    `- C) font-family

`    `- D) border

29\. What is the purpose of the `npm update` command?

`    `- A) To update npm packages to their latest versions

`    `- B) To install npm packages

`    `- C) To remove npm packages

`    `- D) To update npm packages to their latest versions within specified version ranges (Correct)

30\. Which HTML tag is used to define an image?

`    `- A) <img> (Correct)

`    `- B) <image>

`    `- C) <picture>

`    `- D) <src>

31\. What is the purpose of the `git log` command?

`    `- A) To list all remote repositories

`    `- B) To display the commit history of the repository (Correct)

`    `- C) To list all branches

`    `- D) To list untracked files

32\. Which CSS property is used to specify the width of an element?

`    `- A) height

`    `- B) width (Correct)

`    `- C) size

`    `- D) length

33\. What is the purpose of the `npm link` command?

`    `- A) To install npm packages globally

`    `- B) To link a package folder to the local npm environment (Correct)

`    `- C) To uninstall npm packages

`    `- D) To publish npm packages

34\. Which HTML tag is used to define a paragraph?

`    `- A) <p> (Correct)

`    `- B) <paragraph>

`    `- C) <para>

`    `- D) <text>

35\. What is the purpose of the `git fetch` command?

`    `- A) To download new data from a remote repository (Correct)

`    `- B) To delete a branch

`    `- C) To merge changes from a remote repository into the local repository

`    `- D) To switch between branches

36\. Which CSS property is used to specify the height of an element?

`    `- A) height (Correct)

`    `- B) width

`    `- C) size

`    `- D) length

37\. What is the purpose of the `npm ci` command?

`    `- A) To install npm packages


`    `- B) To clean the npm cache

`    `- C) To install dependencies based on package-lock.json or npm-shrinkwrap.json (Correct)

`    `- D) To update npm packages

38\. Which HTML tag is used to define a button?

`    `- A) <button> (Correct)

`    `- B) <input type="button">

`    `- C) <btn>

`    `- D) <submit>

39\. What is the purpose of the `git tag` command?

`    `- A) To create a new branch

`    `- B) To create, list, delete, or verify tags (Correct)

`    `- C) To merge branches

`    `- D) To switch between branches

40\. Which CSS property is used to specify the font style?

`    `- A) font-style (Correct)

`    `- B) font-family

`    `- C) font-weight

`    `- D) font-size

41\. What is the purpose of the `npm dedupe` command?

`    `- A) To update npm packages

`    `- B) To remove duplicate dependencies from the node\_modules folder (Correct)

`    `- C) To install npm packages

`    `- D) To uninstall npm packages

42\. Which HTML tag is used to define a header?

`    `- A) <header> (Correct)

`    `- B) <head>

`    `- C) <h>

`    `- D) <heading>

43\. What is the purpose of the `git submodule` command?

`    `- A) To create a new submodule

`    `- B) To initialize, update, or inspect submodules (Correct)

`    `- C) To merge branches

`    `- D) To switch between branches

44\. Which CSS property is used to specify the border radius?

`    `- A) border-radius (Correct)

`    `- B) border-width

`    `- C) border-color

`    `- D) border-style

45\. What is the purpose of the `npm pack` command?

`    `- A) To install npm packages

`    `- B) To create a tarball from a package (Correct)

`    `- C) To update npm packages

`    `- D) To publish npm packages

46\. Which HTML tag is used to define a division or section in a webpage?

`    `- A) <div> (Correct)

`    `- B) <section>

`    `- C) <dividing>

`    `- D) <block>

47\. What is the purpose of the `git bisect` command?

`    `- A) To merge branches

`    `- B) To identify the commit that introduced a bug using binary search (Correct)

`    `- C) To switch between branches

`    `- D) To list untracked files

48\. Which CSS property is used to specify the line spacing?

`    `- A) line-height (Correct)

`    `- B) text-decoration

`    `- C) text-transform

`    `- D) font-size

49\. What is the purpose of the `npm config` command?

`    `- A) To set npm configuration options

`    `- B) To get or set npm configuration values on the command line (Correct)

`    `- C) To install npm packages

`    `- D) To uninstall npm packages

50\. Which HTML tag is used to define an unordered list?

`    `- A) <ol>

`    `- B) <li>

`    `- C) <ul> (Correct)

`    `- D) <list>
